
<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <!--Conteudo Aqui -->
        <div class="push-top">
            <?php if(session()->get('success')): ?>
                <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>  
                </div><br />
            <?php endif; ?>
            <table class="table">
                <thead>
                    <tr class="table-warning">
                    <td>ID</td>
                    <td>Name</td>
                    <td>Email</td>
                    <td>Phone</td>
                    <td>Password</td>
                    <td class="text-center">Action</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($Category->id); ?></td>
                        <td><?php echo e($Category->idUser); ?></td>
                        <td><?php echo e($Category->categoryName); ?></td>
                        <td><?php echo e($Category->limit); ?></td>
                        <td class="text-center">
                            <a href="<?php echo e(route('categories.edit', $categories->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                            <form action="<?php echo e(route('category.destroy', $categories->id)); ?>" method="post" style="display: inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <div>
        <!--Conteudo Aqui -->
    </div>
    <!-- content-wrapper ends -->
    <!-- partial:partials/_footer.html -->

    <!-- partial -->
</div>

<?php $__env->stopSection(); ?>


<div class="push-top">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <table class="table">
    <thead>
        <tr class="table-warning">
          <td>ID</td>
          <td>Name</td>
          <td>Email</td>
          <td>Phone</td>
          <td>Password</td>
          <td class="text-center">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $Category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($Category->id); ?></td>
            <td><?php echo e($Category->idUser); ?></td>
            <td><?php echo e($Category->categoryName); ?></td>
            <td><?php echo e($Category->limit); ?></td>
            <td class="text-center">
                <a href="<?php echo e(route('categories.edit', $categories->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                <form action="<?php echo e(route('students.destroy', $students->id)); ?>" method="post" style="display: inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                  </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
<?php echo $__env->make('auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\bruno\OneDrive\Documentos\GitHub\ApiPocket\PASproject\resources\views/auth/create-category.blade.php ENDPATH**/ ?>